
var album = {'collections' : [
    {'collection_name': 'collection 0', 'pictures' : [
        {name : 'Picture 1', src : "https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Coast_Garter_Snake.jpg/500px-Coast_Garter_Snake.jpg", color : 'red'},
        {name : 'Picture 2', src : "https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Bartagame_fcm.jpg/500px-Bartagame_fcm.jpg", color : 'green'}]},

    {'collection_name': 'collection 1', 'pictures' : [
        {name : 'Picture 1', src : "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Chelonia_mydas_is_going_for_the_air.jpg/440px-Chelonia_mydas_is_going_for_the_air.jpg", color : 'blue'},
        {name : 'Picture 2', src : "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Turtle3m.JPG/500px-Turtle3m.JPG", color : 'orange'}]}
    ]
}
